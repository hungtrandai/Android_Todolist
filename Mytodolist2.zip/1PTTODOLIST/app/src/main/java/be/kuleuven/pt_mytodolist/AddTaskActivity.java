package be.kuleuven.pt_mytodolist;

import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatSpinner;

import com.bumptech.glide.Glide;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import be.kuleuven.pt_mytodolist.model.Image;
import be.kuleuven.pt_mytodolist.model.Task;
import be.kuleuven.pt_mytodolist.model.TaskTmp;

public class AddTaskActivity extends AppCompatActivity {
    private EditText taskName, taskCategory;
    private TextView taskTime;
    private Button btnCreateAt, buttonSave;
    private RatingBar taskRating;
    private ImageButton back;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);
        findMyViewById();
        onClick();
        getListImage();
        Calendar calendar = Calendar.getInstance();
        taskTime.setText(DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(calendar.getTimeInMillis())));
        taskTime.setOnClickListener(view -> {
            Calendar cal = Calendar.getInstance();
            int hour = cal.get(Calendar.HOUR_OF_DAY);
            int minute = cal.get(Calendar.MINUTE);
            TimePickerDialog mTimePicker;
            mTimePicker = new TimePickerDialog(AddTaskActivity.this, (timePicker, selectedHour, selectedMinute) -> {
                cal.set(Calendar.HOUR, selectedHour);
                cal.set(Calendar.MINUTE, selectedMinute);
                taskTime.setText(DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(cal.getTimeInMillis())));
            }, hour, minute, false);
            mTimePicker.show();
        });


    }

    private void showLoading() {
        progressDialog = new ProgressDialog(AddTaskActivity.this);
        progressDialog.setMessage("Loading, please wait...");
        progressDialog.show();
    }

    private AppCompatSpinner mSpinner;

    private void test() {
        ArrayAdapter<CharSequence> sequenceArrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, list);
        sequenceArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSpinner.setAdapter(sequenceArrayAdapter);
        mSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {



            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    String[] list;
    ArrayList<Image> listImage;

    private void getListImage() {
        showLoading();
        APIConnection.getListImage(this, new GetListImageListener() {
            @Override
            public void onSuccess(ArrayList<Image> lt) {
                listImage = lt;
                list = new String[lt.size()];
                for (int i = 0; i < lt.size(); i++) {
                    list[i] = "" + lt.get(i).getImageId();
                }
                progressDialog.dismiss();
                test();
            }

            @Override
            public void onError(String errorMessage) {
                progressDialog.dismiss();
            }
        });
    }

    private void onClick() {
        buttonSave.setOnClickListener(view -> {
            if (!taskName.getText().toString().isEmpty() && !taskTime.getText().toString().isEmpty() && !taskCategory.getText().toString().isEmpty()) {
                progressDialog = new ProgressDialog(AddTaskActivity.this);
                progressDialog.setMessage("Uploading, please wait...");
                progressDialog.show();
                Task task = new Task();
                task.setTaskTime(taskTime.getText().toString());
                task.setTaskName(taskName.getText().toString());
                task.setTaskCategory(taskCategory.getText().toString());
                task.setTaskRating(taskRating.getRating());
                task.setImageContent(listImage.get(mSpinner.getSelectedItemPosition()).getImageContent());
                task.setImageName(listImage.get(mSpinner.getSelectedItemPosition()).getImageName());
                task.setImageId(listImage.get(mSpinner.getSelectedItemPosition()).getImageId());

                APIConnection.insertTask(AddTaskActivity.this, task, new TaskListener() {
                    @Override
                    public void onSuccess() {
                        progressDialog.dismiss();
                        Intent intent = new Intent();
                        intent.putExtra("insert_task", task);
                        setResult(RESULT_OK, intent);
                        finish();
                    }

                    @Override
                    public void onError(String errorMessage) {
                        progressDialog.dismiss();
                        Toast.makeText(AddTaskActivity.this, "There is an error out, please try again after", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });

            } else {
                Toast.makeText(AddTaskActivity.this, "There is an empty space", Toast.LENGTH_SHORT).show();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    private void findMyViewById() {
        taskName = findViewById(R.id.taskName);
        taskCategory = findViewById(R.id.idCat);
        taskTime = findViewById(R.id.idTime);
        taskRating = findViewById(R.id.taskRating);
        buttonSave = findViewById(R.id.buttonSave);

        back = findViewById(R.id.back);
        mSpinner = findViewById(R.id.mSpinner);

    }

}